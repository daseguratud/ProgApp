﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class CSVManager
    {
        private string _fileName {  get; set; }
        public char Separador { get => ','; }
        public CSVManager(string fileName) {
            _fileName = fileName;
        }
        public List<string[]> Read() { 
            var lineas = File.ReadAllLines(_fileName);
            var result = new List<string[]>();
            foreach (var line in lineas) {
                result.Add(line.Split(Separador));
            }
            return result;
        }
        public void Save(List<string[]> datos)
        {
            var lineas = new List<string>();
            foreach (var dato in datos)
            {
                lineas.Add(string.Join(Separador, dato));
            }
            File.WriteAllLines(_fileName, lineas);
        }
        public void Add(string[] data)
        {
            var lineas = new List<string>();
            lineas.Add(string.Join(Separador,data));
            File.AppendAllLines(_fileName, lineas);
        }
    }
}
