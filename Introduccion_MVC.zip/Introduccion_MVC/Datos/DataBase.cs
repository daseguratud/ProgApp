﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DataBase
    {
        private string _tipodispositivosFile="data/tipodispositivos.csv";
        private string _dispositivosFile= "data/dispositivos.csv";
        private string _transaccionesFile= "data/transacciones.csv";

        private CSVManager TipoDispositivoDB { get; set; }
        private CSVManager DispositivoDB { get; set; }
        private CSVManager TransaccionesDB { get; set; }

        public List<Dominio.TipoDispositivo> TiposDispositivo {  get; set; }
        public List<Dominio.Dispositivo> Dispositivos {  get; set; }
        public List<Dominio.Transaccion> Transacciones {  get; set; }
        public DataBase() {
            TipoDispositivoDB = new CSVManager(_tipodispositivosFile);
            DispositivoDB = new CSVManager(_dispositivosFile);
            TransaccionesDB = new CSVManager(_transaccionesFile);

            TiposDispositivo = TipoDispositivoDB.Read()
                .Select(l=> ArrayToTipoDispositivo(l))
                .ToList();
            Dispositivos= DispositivoDB.Read()
                .Select( d => ArrayToDispositivo(d))
                .ToList();
            Transacciones = TransaccionesDB.Read()
                .Select(t => ArrayToTransaccion(t))
                .ToList();
        }
        private Dominio.TipoDispositivo ArrayToTipoDispositivo(string[] campos)
        {
            return new Dominio.TipoDispositivo
            {
                TipoDispositivoId = long.Parse(campos[0]),
                Descripcion = campos[1]
            };
        }
        private Dominio.Dispositivo ArrayToDispositivo(string[] campos)
        {
            return new Dominio.Dispositivo
            {
                DispositivoId = long.Parse(campos[0]),
                Nombre = campos[1],
                TipoDispositivo =
                    TiposDispositivo
                    .Single(d => d.TipoDispositivoId == long.Parse(campos[2]))
            };
        }
        private Dominio.Transaccion ArrayToTransaccion(string[] campos)
        {
            return new Dominio.Transaccion
            {
                TransaccionId = long.Parse(campos[0]),
                FechaReporte = DateTime.Parse(campos[1]),
                Dispositivo =
                    Dispositivos.Single(d => d.DispositivoId == long.Parse(campos[2]))
            };
        }
        public void AddTransaccion(DateTime FechaHora, long DispositivoId)
        {
            var nextId = 
                Transacciones.Count<=0?1:
                Transacciones.Max(t => t.TransaccionId) + 1;
            var campos = new string[] { 
                nextId.ToString(),
                FechaHora.ToString("yyyy-MM-dd HH:mm:ss"),
                DispositivoId.ToString()
            };
            TransaccionesDB.Add(campos);
            Transacciones = TransaccionesDB.Read()
                .Select(t => ArrayToTransaccion(t))
                .ToList();
        }
    }
}
