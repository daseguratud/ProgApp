using System.Diagnostics;
using Ejemplo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ejemplo.Controllers
{
    public class DispositivoController : Controller
    {
        private Aplicacion.Dispositivos appDispositivos { get; set; }
        private Aplicacion.Transacciones appTransacciones { get; set; }
        public DispositivoController() { 
            appDispositivos = new Aplicacion.Dispositivos();
			appTransacciones = new Aplicacion.Transacciones();
        }
        public IActionResult Index()
        {
            return View(appDispositivos.Listar());
        }
        public IActionResult Transacciones()
        {
            return View(appTransacciones.Listar());
        }
    }
}
