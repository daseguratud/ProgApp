﻿using Ejemplo.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ejemplo.Controllers
{
	public class TransaccionController : Controller
	{
		private Aplicacion.Transacciones transaccionesApp {  get; set; }
		public TransaccionController()
		{
			transaccionesApp = new Aplicacion.Transacciones();
		}
		[HttpPost]
		public string Reporte(Models.ReporteTransaccion reporte)
		{
			try
			{
				transaccionesApp.Add(reporte.DispositivoId);
				return "Ok";
			}
			catch (Exception ex) { 
				return ex.Message;
			}
		}
	}
}
