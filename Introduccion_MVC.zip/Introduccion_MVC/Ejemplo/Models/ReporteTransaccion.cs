﻿namespace Ejemplo.Models
{
	public class ReporteTransaccion
	{
		public int DispositivoId { get; set; }
	}
}
