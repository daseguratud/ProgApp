﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function OnEmnulaTransaccion() {
    fetch('/Transaccion/Reporte?DispositivoId=1', { method:'POST' })
        .then((r) => { console.log(r); })
        .catch((r) => { console.error(r); })
    //const xhr = new XMLHttpRequest();
    //xhr.open("GET", "/Transaccion/Reporte?DispositivoId=1", true);
    //xhr.onload = (response) => {
    //    console.log(response);
    //};
    //xhr.send(); 
}