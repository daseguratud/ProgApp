﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Aplicacion
{
    public class Dispositivos
    {
        private Datos.DataBase DataBase { get; set; }
        public Dispositivos() { 
            DataBase = new Datos.DataBase();
        }
        public List<Dominio.Dispositivo> Listar()
        {
            return DataBase.Dispositivos;
        }
    }
}
