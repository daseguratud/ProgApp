﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dominio;

namespace Aplicacion
{
    public class Transacciones
    {
        private Datos.DataBase DataBase { get; set; }
        public Transacciones() { 
            DataBase = new Datos.DataBase();
        }
        public List<Dominio.Transaccion> Listar()
        {
            return DataBase.Transacciones;
        }
        public List<Dominio.Transaccion> Listar(long DispositivoId)
        {
            return DataBase.Transacciones
                .Where(t=>t.Dispositivo.DispositivoId==DispositivoId)
                .ToList();
        }

        public void Add(long dispositivoId)
        {
            if (!DataBase.Dispositivos.Any(d => d.DispositivoId == dispositivoId))
            {
                throw new Exception("El dispositivo no existe");
            }
            DataBase.AddTransaccion(DateTime.Now, dispositivoId);
        }
    }
}
