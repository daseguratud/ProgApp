﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Dispositivo
    {
        public long DispositivoId { get; set; }
        public TipoDispositivo TipoDispositivo { get; set; }
        public String Nombre { get; set; }
    }
}
